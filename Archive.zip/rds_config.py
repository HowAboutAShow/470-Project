#config file containing credentials for rds mysql instance
db_username = "yaboi"
db_password = "mypassword"
db_name = "movieDB" 