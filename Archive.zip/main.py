import sys #import trans
import logging
import rds_config
import pymysql
import json
import math
import operator
from collections import defaultdict

#rds settings
rds_host  = "moviedb.ck4fewpsrpn4.us-east-2.rds.amazonaws.com"
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def requestShow(event):
    lst = event['body']
    d = json.loads(lst)
    genreDictionary = defaultdict(int)
    desiredGenres = []
    if(d.get('id') != None):
        return requestMore(event)
    else:
        #Structure initial query based on rating and importances entered by users
        querySelects = ""
        for i in range (0, len(d['genres'])):
            itm = d['genres'][i]
            itms = str(itm).split(",")
            genre = (str(itms[0]))[(str(itms[0])).find(": '")+1:(str(itms[0])).find("',")]
            genre = genre.replace("'", "")
            genre = genre.strip(" ")
            
            rating = (str(itms[1]))[(str(itms[1])).find(": '")+1:(str(itms[1])).find("',")]
            rating = rating.replace("'", "").strip()
            importance = (str(itms[2]))[(str(itms[2])).find(": '")+1:(str(itms[2])).find("'}")]
            importance = importance.replace("'", "").strip()
            
            if rating != "Rating":
                if (querySelects != "") & (i > 0):
                    querySelects = querySelects + " UNION DISTINCT "
                if importance != "Importance":
                    genreDictionary[genre] = int(importance) * int(rating)
                    desiredGenres.append(genre)
                    weight = int(rating.strip()) * (int(importance.strip())/10)
                    querySelects = querySelects + " SELECT MovieID, Rating*" + str(weight) + " AS 'WeightedRating' FROM " + genre.lower() + " WHERE NumVotes > 6000 "
        query = "select Categories, Name, TitleBasic.MovieID from TitleBasic, (" + querySelects + " ORDER BY WeightedRating DESC LIMIT 100) sorted where TitleBasic.MovieID = sorted.MovieID"

        try:
            conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
        except:
            logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
            sys.exit()

        logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
        queryResult = []
        with conn.cursor() as cur:
            cur.execute(query)
            conn.commit()
            conn.close()

            for row in cur:
                queryResult.append(str(row))
        
        #Based on result of initial query, find better results with second algorithm
        movieIDs = []
        movieNames = []
        ratings = []
        genreOptions =["Comedy", "Drama", "Action", "Adventure", "Animation", "Biography", "Crime", "Documentary", "Family", "Fantasy", "History", "Horror", "Music", "Musical", "Mystery", "Romance", "Sports", "Thriller", "War", "Western", "Scifi"]
        print("desiredGenres", desiredGenres)
        for row in queryResult:
            items = row.split(", ")
            
            movieName = items[1]
            movieNames.append(movieName)
            
            movieID = items[2].strip(")").strip("'")
            movieIDs.append(movieID)

            genres = items[0].split(",")
            for i in range(0, len(genres)):
                genres[i] = genres[i].strip("(").strip("'").strip("\"")
            genres = set(genres)
            
            genrequery = "select Rating from masterTableVotes where \""+ movieID + "\"= masterTableVotes.MovieID"
            genrequery2 = "select NumVotes from masterTableVotes where \"" + movieID + "\"= masterTableVotes.MovieID"
            movieRating = 0
            numVotes = 0
            newModRating = 0
            
            try:
                conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
            except:
                logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
                sys.exit()

            with conn.cursor() as cur:

                cur.execute(genrequery)
                conn.commit()
                for row in cur:
                    movieRating =  float(row[0])
                    
                cur.execute(genrequery2)
                conn.commit()
                for row in cur:
                    numVotes =  int(row[0])

                conn.close()
                   
            for word in desiredGenres:
                if word in genres:
                    importanceTimesRating = genreDictionary[word]
                    #print(movieRating,'*', (1+float(importanceTimesRating)/10), "*", math.log10(numVotes+1))
                    newModRating += float((float(movieRating) * (1+float(importanceTimesRating/10)) * float(math.log10(numVotes+1))))/100
            ratings.append(newModRating)
            
        moviesRatingsZip = zip(movieIDs,movieNames, ratings)
        moviesRatingsList = list(moviesRatingsZip)
        
        moviesRatingsList.sort(key=operator.itemgetter(2), reverse = True)
        print("moviesRatingsList: ", moviesRatingsList)

        top10 = ""
        upperBound = 10
        if len(moviesRatingsList) < 10:
            upperBound = len(moviesRatingsList)
        for i in range (0,upperBound):
            top10 += "('" + moviesRatingsList[i][1].strip("'").strip() + "', '" + moviesRatingsList[i][0].strip("'").strip() + "')"
        if len(top10) < 10:
            top10 += "('none', 'none')"

        print(top10)
        return top10


def requestMore(event):
    lst = event['body']
    print(event['body'])
    d = json.loads(lst)
    genreOptions = ["Comedy", "Drama", "Action", "Adventure", "Animation", "Biography", "Crime", "Documentary", "Family", "Fantasy", "History", "Horror", "Music", "Musical", "Mystery", "Romance", "Sports", "Thriller", "War", "Western", "Scifi"]
    genrevec = [0] * len(genreOptions)
    #if(d['id'] != None):
    #genrequery = "SELECT * FROM masterTable WHERE masterTable.movieID='" + d['id'] + "';"
    genrequery = "SELECT * FROM masterTable WHERE masterTable.movieID='" + "tt0804503" + "';"
    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    except:
        logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
        sys.exit()
    logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
    queryResult = ""
    with conn.cursor() as cur:
        cur.execute(genrequery)
        conn.commit()
        conn.close()
        for row in cur:
            queryResult += str(row)
    print(queryResult)
    elements = queryResult.split("'")
    print(elements)
    genres = elements[7].split(",")
    print(genres)
    #genres = ["drama"]
    query = ""
    denA = 0
    for i in range (0, len(genres)):
        if (query != "") & (i > 0):
            query = query + " UNION DISTINCT "
        ind = genreOptions.index(genres[i].strip())
        genrevec[ind] = 1
        denA += 1
        query = query + " SELECT * FROM " + genres[i].strip().lower() + " WHERE NumVotes > 6000 "
    denA = math.sqrt(denA)
    query = "SELECT * FROM TitleBasic, (" + query + ") sorted where TitleBasic.MovieID = sorted.MovieID ORDER BY Rating DESC; "
    print(query)

    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    except:
        logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
        sys.exit()

    logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
    queryResult = ""
    queryReturn = ""
    with conn.cursor() as cur:
        cur.execute(query)
        conn.commit()
        conn.close()

        #showsdict = {}
        shows = []
        for row in cur:
            #queryResult += str(row)
            queryResult = str(row)
            #Get the genres the movie is listed as
            #split the genres into a vector
            #for each result, create a vector and compare it to orginal vector (compare differences)
            qgenrevec = [0] * len(genreOptions)
            queryelements = queryResult.split("', '")
            #print(len(queryelements))
            #print(queryelements)
            if len(queryelements) > 3:
                title = queryelements[1]
                subelements = queryelements[3].split(",")
                rating = subelements[2].replace("'", "").strip()
                #print(title + " " + rating)
                querygenres = queryelements[2].split(",")
                #print(querygenres)
                num = 0
                denB = 0
                for i in range (0, len(querygenres)):
                    if querygenres[i].strip("'").strip(" ") in genreOptions:
                        ind = genreOptions.index(querygenres[i].strip("'").strip(" "))
                        #if (ind >= 0) & (ind < len(qgenrevec)):
                        qgenrevec[ind] = 1
                        num += (1* genrevec[ind])
                        denB += 1
                cosinesim = num/(denA*math.sqrt(denB))
                #showsdict[title] = cosinesim*float(rating)
                rating = rating.strip("Decimal(").strip(")")
                shows.append((title, cosinesim*float(rating)))
                #print(cosinesim)
                #compute cosine sim
        #print(len(shows))
        sorteddict = sorted(shows, key= lambda x:x[1], reverse=True)
        for i in range(0,15):
            #print(sorteddict[i][0] + " " + str(sorteddict[i][1]))
            queryReturn += "('" + str(sorteddict[i][0]) + "', " + str(sorteddict[i][1]) + ")"
    print(queryReturn)
    return queryReturn

def main(event, context):
    res = requestShow(event)
    return { 'statusCode': 200, 'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'}, 'body': json.dumps({'result': res})}
