import sys
import logging
import rds_config
import pymysql
import json
#rds settings
rds_host  = "moviedb.ck4fewpsrpn4.us-east-2.rds.amazonaws.com"
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name


logger = logging.getLogger()
logger.setLevel(logging.INFO)

class GenRate:
    def __init__(self, genre, rating):
        self.genre = genre
        self.rating = rating


def doStuff(event):
    lst = event['body']
    print(event['body'])
    d = json.loads(lst)
    querySelects = ""
    for i in range (0, len(d['genres'])):
        itm = d['genres'][i]
        itms = str(itm).split(",")
        genre = (str(itms[0]))[(str(itms[0])).find(": '")+1:(str(itms[0])).find("',")]
        genre = genre.replace("'", "")
        rating = (str(itms[1]))[(str(itms[1])).find(": '")+1:(str(itms[1])).find("',")]
        rating = rating.replace("'", "").strip()
        #importance = (str(itms[2]))[(str(itms[2])).find(": '")+1:(str(itms[2])).find("'}")]
        if rating != "Rating":
            if (querySelects != "") & (i > 0):
                querySelects = querySelects + " UNION DISTINCT "
            querySelects = querySelects + " SELECT MovieID, '" + genre.strip() + "', ModRating*" + rating.strip() + " AS 'WeightedRating' FROM " + genre.lower() 
            #if (i < len(d['genres'])-1):
            #    querySelects = querySelects + " UNION DISTINCT "
    query = "select Name from TitleBasic, (" + querySelects + " ORDER BY WeightedRating DESC LIMIT 10) sorted where TitleBasic.MovieID = sorted.MovieID"
    print(query)
    
    
    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    except:
        logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
        sys.exit()

    logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
    queryResult = ""
    with conn.cursor() as cur:
        cur.execute(query)
        conn.commit()
        conn.close()

        for row in cur:
            #logger.info(row)    
            #print(row)
            queryResult += str(row)
        
    return queryResult
    #return { 'statusCode': 200, 'headers': {'Content-Type': 'application/json'}, 'body': json.dumps({'key1': 'value1'})}
    #return { 'statusCode' : 200, 'headers' : { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'} }

def main(event, context):
    res = doStuff(event)
    return { 'statusCode': 200, 'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'}, 'body': json.dumps({'result': res})}


#doStuff(None)